<html>
 

  
    <style>   
        body{  
    background-image: url("index.jpg");      
       margin-top: 100px;  
    margin-bottom: 130px;  
    margin-right: 150px;  
    margin-left: 150px;  
	background-size: 100%;
    background-attachment: fixed; 
	color: #261A15;
    font-family: 'Yantramanav', sans-serif;;  
    font-size: 150%;  
     
        }  
<style>
a:link {
    color: green;
}
a:visited {
    color: red;
}
a:hover {
    color: red;
}
a:active {
    color: red;
}

</style>

<head>
  <title>AIRLINE RESERVATION SYSTEM</title>
</head>

<body style=" 
    height: 100%; 
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;" >
<div align="CENTER" >
<h1 style="color: black;">AIRLINE RESERVATION SYSTEM</h1>
<div>

<!-- <br><a href="login.php" >User Login </a><br> -->
<br><a href="login.php">User Login</a><br>
<!-- <br><a href="adminlogin.php">Admin Login </a><br> -->
<br><a href="adminlogin.php">Admin Login </a><br></h2>
</div>
</div>
</body> 
</html>